﻿#Create Desktop Icons
echo "Creating Desktop Icons"
if([System.IO.File]::Exists("c:\programdata\microsoft\windows\start menu\programs\Microsoft Office 2013")){
    copy "c:\programdata\microsoft\windows\start menu\programs\Microsoft Office 2013\excel*.lnk" c:\users\public\desktop
	copy "c:\programdata\microsoft\windows\start menu\programs\Microsoft Office 2013\word*.lnk" c:\users\public\desktop
	copy "c:\programdata\microsoft\windows\start menu\programs\Microsoft Office 2013\outlook*.lnk" c:\users\public\desktop
	copy "c:\programdata\microsoft\windows\start menu\programs\Accessories\internet explorer.lnk" c:\users\public\desktop
	$WshShell = New-Object -comObject WScript.Shell
	$Shortcut = $WshShell.CreateShortcut("c:\users\public\Desktop\Internet Explorer.lnk")
	$Shortcut.TargetPath = "C:\Program Files\internet explorer\iexplore.exe"
	$Shortcut.Save()
}else{
	copy "c:\programdata\microsoft\windows\start menu\programs\excel*.lnk" c:\users\public\desktop
	copy "c:\programdata\microsoft\windows\start menu\programs\word*.lnk" c:\users\public\desktop
	copy "c:\programdata\microsoft\windows\start menu\programs\outlook*.lnk" c:\users\public\desktop
	$WshShell = New-Object -comObject WScript.Shell
	$Shortcut = $WshShell.CreateShortcut("c:\users\public\Desktop\Internet Explorer.lnk")
	$Shortcut.TargetPath = "C:\Program Files\internet explorer\iexplore.exe"
	$Shortcut.Save()
}

#Set Default Apps
Echo "Setting Program Defaults"
#dism /online /Import-DefaultAppAssociations:"c:\BSS\DefaultApps.xml"
Unblock-File C:\bss\AssociateFileExtensions.psm1
Import-Module C:\bss\AssociateFileExtensions.psm1 -force
AssociateFileExtensions -FileExtensions .bmp,.dib,.emf,.gif,.ico,.jfif,.jpe,.jpeg,.jpeg,.png,.rle,.tif,.tiff,.wmf -OpenAppPath "C:\WINDOWS\system32\mspaint.exe"
AssociateFileExtensions -FileExtensions .fdf,.pdf,.pdfxml,.pdx,.xdf,.xfdf -openapppath "C:\Program Files (x86)\Adobe\Acrobat Reader DC\Reader\AcroRd32.exe"
AssociateFileExtensions -FileExtensions .htm,.html,.shtml,.svg,.webp,.xht,.xhtml -openapppath "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"

#File Explorer
Echo 'Setting windows explorer to default to "This PC"'
Set-ItemProperty -Path REGISTRY::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name LaunchTo -Value 1

#Unpin Edge from Taskbar
Echo "Unpinning Edge from the taskbar"
function UnPin-App ( [string]$appname ) {
	try {
		$exec = $false
		
		((New-Object -Com Shell.Application).NameSpace('shell:::{4234d49b-0245-4df3-b780-3893943456e1}').Items() | ?{$_.Name -eq $appname}).Verbs() | ?{$_.Name.replace('&','') -match 'Unpin from taskbar'} | %{$_.DoIt(); $exec = $true}
		
		if ($exec) {
			Write "App '$appname' unpinned from Taskbar"
		} else {
			Write "'$appname' not found or 'Unpin from taskbar' not found on item!"
		}
		
	} catch {
		Write-Error "Error unpinning $appname from taskbar!"
	}
}

UnPin-App "Microsoft Edge"