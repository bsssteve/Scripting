Add-Type -AssemblyName Microsoft.VisualBasic
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.IO.Compression.FileSystem
Import-Module BitsTransfer

$O365Options = @("c:\odt\installO365BusRet32.xml","c:\odt\installO365BusRet32_SCA.xml","c:\odt\installO365BusRet64.xml","c:\odt\installO365BusRet64_SCA.xml","c:\odt\installO365ProPlus32.xml","c:\odt\installO365ProPlus32_SCA.xml","c:\odt\installO365ProPlus64.xml","c:\odt\installO365ProPlus64_SCA.xml","c:\odt\installHomeBusiness32.xml","c:\odt\installHomeBusiness64.xml","c:\odt\installProfessional32.xml","c:\odt\installProfessional64.xml","c:\odt\installO365ProjectPro32.xml","c:\odt\installO365ProjectPro64.xml","c:\odt\installO365ProjectVisio32.xml","c:\odt\installO365ProjectVisio64.xml","c:\odt\installO365VisioPro32.xml","c:\odt\installO365VisioPro64.xml")

$O365Versions = @("O365 Business Retail 32-bit","O365 Business Retail 32-bit_SCA","O365 Business Retail 64-bit","O365 Business Retail 64-bit_SCA","O365 ProPlus 32-bit","O365 ProPlus 32-bit_SCA","O365 ProPlus 64-bit","O365 ProPlus 64-bit_SCA","Home & Business 32-bit","Home & Business 64-bit","Professional 32-bit","Professional 64-bit","O365 Project Pro 32-bit","O365 Project Pro 64-bit","Project & Visio 32-bit","Project & Visio 64-bit","O365 Visio Pro 32-bit","O365 Visio Pro 64-bit")

#Download ODT
$url = "https://github.com/bsssteve/Scripting/raw/master/ODTALL.zip"
$output = "c:\odt\odtall.zip"
$pathexists = Test-Path C:\odt
if ($pathexists -eq "true")
{
	Remove-Item -path "c:\odt" -recurse
}

New-Item -Path "c:\" -Name "odt" -ItemType "directory"

write-host "Downloading Media"

Start-BitsTransfer -Source $url -Destination $output

#Extract ODT.zip
function unzip {
    param( [string]$ziparchive, [string]$extractpath )
    [System.IO.Compression.ZipFile]::ExtractToDirectory( $ziparchive, $extractpath )
}

unzip "c:\odt\odtall.zip" "c:\odt"

#expand-archive -literalpath "c:\odt\odt.zip" destinationpath "c:\odt"

#Remove-Item c:\odt\odtall.zip -force -recurse

$path="c:\odt\*.*"
$pathexists = Test-Path c:\odt
write-host $pathexists
if ($pathexists -eq "true")
{
	#Installing Office
	
	[void][Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic')
	$title = 'Office 365 Version'
	$msg   = 'Which version of Office 365.  
	
	Input 0 for O365 Business Retail 32-bit
	Input 1 for O365 Business Retail 32-bit_SCA*
	Input 2 for O365 Business Retail 64-bit
	Input 3 for O365 Business Retail 64-bit_SCA*
	Input 4 for O365 ProPlus 32-bit
	Input 5 for O365 ProPlus 32-bit_SCA*
	Input 6 for O365 ProPlus 64-bit
	Input 7 for O365 ProPlus 64-bit_SCA*
	Input 8 for Home & Business 32-bit**
	Input 9 for Home & Business 64-bit**
	Input 10 for Professional 32-bit**
	Input 11 for Professional 64-bit**
	Input 12 for O365 Project Pro 32-bit
	Input 13 for O365 Project Pro 64-bit
	Input 14 for O365 Project & Visio 32-bit
	Input 15 for O365 Project & Visio 64-bit
	Input 16 for O365 Visio Pro 32-bit
	Input 17 for O365 Visio Pro 64-bit
	
	* = Shared Computer Activation
	** = Perpetual Office Products'
	$RequestedVersion = [Microsoft.VisualBasic.Interaction]::InputBox($msg, $title)
    if ($RequestedVersion -eq "")
    {
        [System.Windows.Forms.MessageBox]::Show("Operation Cancelled `n `nProgram Terminating",'Error','OK','Error')
		break
    }
	$versiontoinstall = "none"
	$a=0
	
	foreach ($option in $O365Options)
	{
		if ($a -eq $RequestedVersion)
		{
			$versiontoinstall = $O365Options[$a]
			$string = $O365Versions[$a]
			$checking=[System.Windows.Forms.MessageBox]::Show("$string will be installed `n `nIs this Correct?", "Confirmation" , 4)
			if ($checking -eq "NO") 
			{
				[System.Windows.Forms.MessageBox]::Show("Process terminated by user",'Error','OK','Error')
				break
			}
		}
		$a = $a+1
	}
	
	if ($versiontoinstall -eq "none")
	{
		[System.Windows.Forms.MessageBox]::Show("Invalid Input `n `nProgram Terminating",'Error','OK','Error')
		break
	}
	
	#Office Install
	c:\odt\Setup.exe /configure $versiontoinstall
	copy "c:\programdata\microsoft\windows\start menu\programs\excel*.lnk" c:\users\public\desktop
	copy "c:\programdata\microsoft\windows\start menu\programs\word*.lnk" c:\users\public\desktop
	copy "c:\programdata\microsoft\windows\start menu\programs\outlook*.lnk" c:\users\public\desktop
	
	Remove-Item -path "c:\odt" -recurse
		
}
else
{
	write-host "Required files are missing from c:\odt for installation. Script terminating."
}