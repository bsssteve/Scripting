﻿#Change RDP Ports
Set-NetFirewallRule -DisplayName "Remote Desktop - User Mode (TCP-In)" -Enabled True
Set-NetFirewallRule -DisplayName "Remote Desktop - User Mode (UDP-In)" -Enabled True

#Allow Ping Response for IPv4 - Optional 
New-NetFirewallRule -DisplayName "Allow inbound ICMPv4" -Direction Inbound -Protocol ICMPv4 -IcmpType 8 -Action Allow

#File Sharing - Optional 
Set-NetFirewallRule -DisplayGroup "File And Printer Sharing" -Enabled True
Set-NetFirewallRule -Displaygroup "Windows Management Instrumentation (WMI)" -Enabled True