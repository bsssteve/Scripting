﻿## PREP
#Copy ADMX & ADML File to %SystemRoot%\PolicyDefination
Get-ChildItem -Path C:\CIS | ? Name -like "*.admx" | ForEach-Object {Copy-Item C:\CIS\$_ -Destination C:\Windows\PolicyDefinitions}
Get-ChildItem -Path C:\CIS | ? Name -like "*.adml" | ForEach-Object {Copy-Item C:\CIS\$_ -Destination C:\Windows\PolicyDefinitions\en-US}

#Silent Install LAPS 
msiexec.exe /i C:\CIS\LAPS.x64.msi /quiet

## Install
.\C:\CIS\LGPO.exe /s "C:\CIS\CIS-WINSRV.inf"
.\C:\CIS\LGPO.exe /ac "C:\CIS\CIS-WINSRV.csv"
.\C:\CIS\LGPO.exe /m "C:\CIS\Machine.pol"
.\C:\CIS\LGPO.exe /u "C:\CIS\user.pol"

## Firewall
#Change RDP Ports
Set-NetFirewallRule -DisplayName "Remote Desktop - User Mode (TCP-In)" -Enabled True
Set-NetFirewallRule -DisplayName "Remote Desktop - User Mode (UDP-In)" -Enabled True

#Allow Ping Response for IPv4 - Optional 
New-NetFirewallRule -DisplayName "Allow inbound ICMPv4" -Direction Inbound -Protocol ICMPv4 -IcmpType 8 -Action Allow

#File Sharing - Optional 
Set-NetFirewallRule -DisplayGroup "File And Printer Sharing" -Enabled True
Set-NetFirewallRule -Displaygroup "Windows Management Instrumentation (WMI)" -Enabled True

## Post Install

#Disable Online Tips
$RegPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer"
$OnlineTips = "AllowOnlineTips"
New-ItemProperty -Path $RegPath -Name $OnlineTips -Value "0" -PropertyType DWord

#Set 'NetBIOS node type' to 'P-node' (Ensure NetBT Parameter 'NodeType' is set to '0x2 (2)')
$NodeType = "NodeType"
$RegPathNodeType = "HKLM:\System\CurrentControlSet\Services\NetBT\Parameters"
New-ItemProperty -Path $RegPathNodeType -Name NodeType -Value "0x2" -PropertyType DWord

#Remote host allows delegation of non-exportable credentials' is set to 'Enabled
$RegPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows"
$CredentialDelegation = "CredentialsDelegation"
New-Item -Path $RegPath -Name $CredentialDelegation
New-ItemProperty -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name AllowProtectedCreds -Value "1" -PropertyType DWord

#Ensure 'Configure Authenticated Proxy usage for the Connected User Experience and Telemetry service' is set to 'Enabled: Disable Authenticated Proxy usage'
$RegPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection"
$DisableAuthProxy = "DisableEnterpriseAuthProxy"
New-ItemProperty -Path $RegPath -Name $DisableAuthProxy -Value "1" -PropertyType DWord

#Ensure 'Allow Message Service Cloud Sync' is set to 'Disabled' (Scored)
$RegPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\"
$Messaging = "Messaging"
New-Item -Path $RegPath -Name $Messaging
New-ItemProperty -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\Messaging -Name AllowMessageSync -Value "0" -PropertyType DWord

#Ensure 'Block all consumer Microsoft account user authentication' is set to 'Enabled'
$RegPath = "HKLM:\SOFTWARE\Policies\Microsoft\"
$MicrosoftAccount = "MicrosoftAccount"
New-Item -Path $RegPath -Name $MicrosoftAccount
New-ItemProperty -Path HKLM:\SOFTWARE\Policies\Microsoft\MicrosoftAccount -Name DisableUserAuth -Value "1" -PropertyType DWord

#Ensure 'Allow Cloud Search' is set to 'Enabled: Disable Cloud Search'
$RegPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\"
$WindowsSearch = "Windows Search"
New-Item -Path $RegPath -Name $WindowsSearch
New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' -Name AllowCloudSearch -Value "0" -PropertyType Dword

##Registry
c:\CIS\_5_Hardening.reg