﻿#Copy ADMX & ADML File to %SystemRoot%\PolicyDefination
Get-ChildItem -Path C:\CIS | ? Name -like "*.admx" | ForEach-Object {Copy-Item C:\CIS\$_ -Destination C:\Windows\PolicyDefinitions}
Get-ChildItem -Path C:\CIS | ? Name -like "*.adml" | ForEach-Object {Copy-Item C:\CIS\$_ -Destination C:\Windows\PolicyDefinitions\en-US}

#Silent Install LAPS 
msiexec.exe /i C:\CIS\LAPS.x64.msi /quiet