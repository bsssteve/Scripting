Add-Type -AssemblyName Microsoft.VisualBasic
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.IO.Compression.FileSystem
Import-Module BitsTransfer

$path="C:\bss\*.*"
$pathexists = Test-Path C:\bss
write-host $pathexists
if ($pathexists -eq "true")
{
	#Variables
	#Client ID (PC Name)
	[void][Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic')
	$title = 'Client ID'
	$msg   = 'Enter the Client ID (for the PC name)'
	$CID = [Microsoft.VisualBasic.Interaction]::InputBox($msg, $title)

	#Install Office 365
	$InstallOffice = "no"
	$Office = "c:\BSS\installOfficeBusRet32.xml"

	$UserResponse1= [System.Windows.Forms.MessageBox]::Show("Would you like to install Office?" , "Office" , 4)

	if ($UserResponse1 -eq "YES" ) 
	{
		$InstallOffice = "yes"
		
		$O365Options = @("c:\bss\installO365BusRet32.xml","c:\bss\installO365BusRet32_SCA.xml","c:\bss\installO365BusRet64.xml","c:\bss\installO365BusRet64_SCA.xml","c:\bss\installO365ProPlus32.xml","c:\bss\installO365ProPlus32_SCA.xml","c:\bss\installO365ProPlus64.xml","c:\bss\installO365ProPlus64_SCA.xml","c:\bss\installHomeBusiness32.xml","c:\bss\installHomeBusiness64.xml","c:\bss\installProfessional32.xml","c:\bss\installProfessional64.xml","c:\bss\installO365ProjectPro32.xml","c:\bss\installO365ProjectPro64.xml","c:\bss\installO365ProjectVisio32.xml","c:\bss\installO365ProjectVisio64.xml","c:\bss\installO365VisioPro32.xml","c:\bss\installO365VisioPro64.xml")

		$O365Versions = @("O365 Business Retail 32-bit","O365 Business Retail 32-bit_SCA","O365 Business Retail 64-bit","O365 Business Retail 64-bit_SCA","O365 ProPlus 32-bit","O365 ProPlus 32-bit_SCA","O365 ProPlus 64-bit","O365 ProPlus 64-bit_SCA","Home & Business 32-bit","Home & Business 64-bit","Professional 32-bit","Professional 64-bit","O365 Project Pro 32-bit","O365 Project Pro 64-bit","Project & Visio 32-bit","Project & Visio 64-bit","O365 Visio Pro 32-bit","O365 Visio Pro 64-bit")

		[void][Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic')
		$title = 'Office 365 Version'
		$msg   = 'Which version of Office 365.  
		
		Input 0 for O365 Business Retail 32-bit
		Input 1 for O365 Business Retail 32-bit_SCA*
		Input 2 for O365 Business Retail 64-bit
		Input 3 for O365 Business Retail 64-bit_SCA*
		Input 4 for O365 ProPlus 32-bit
		Input 5 for O365 ProPlus 32-bit_SCA*
		Input 6 for O365 ProPlus 64-bit
		Input 7 for O365 ProPlus 64-bit_SCA*
		Input 8 for Home & Business 32-bit**
		Input 9 for Home & Business 64-bit**
		Input 10 for Professional 32-bit**
		Input 11 for Professional 64-bit**
		Input 12 for O365 Project Pro 32-bit
		Input 13 for O365 Project Pro 64-bit
		Input 14 for O365 Project & Visio 32-bit
		Input 15 for O365 Project & Visio 64-bit
		Input 16 for O365 Visio Pro 32-bit
		Input 17 for O365 Visio Pro 64-bit
		
		* = Shared Computer Activation
		** = Perpetual Office Products'
		
		$a=0
		
		foreach ($option in $O365Options)
		{
			if ($a -eq $RequestedVersion)
			{
				$Office  = $O365Options[$a]
				$string = $O365Versions[$a]
				write-host "$string will be installed"
				
			}
			$a = $a+1
		}
	}

	else 
	{ 
		write-host "User opted not install office"
	}

	#UAC
	$UAC = "on"

	$UserResponse2= [System.Windows.Forms.MessageBox]::Show("Would you disable UAC?" , "User Account Control" , 4)

	if ($UserResponse2 -eq "YES" ) 
	{
		$UAC = "off"
		write-host "UAC will be disabled"
	} 

	else 
	{ 
		write-host "UAC will remain on"
	}
	
	#TimeZone
	$TimeZone = "Eastern Standard Time"

	[void][Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic')
	$title = 'Time Zone'
	$msg   = 'Which TimeZone?.  
	
	Enter E for Eastern 
	Enter C for Central
	Enter M for Mountain
	Enter P for Pacific'
		
	$TZ = [Microsoft.VisualBasic.Interaction]::InputBox($msg, $title)
	
	Switch($tz)
	{
		E {$timezone="Eastern Standard Time"}
		C {$timezone="Central Standard Time"}
		M {$timezone="Mountain Standard Time"}
		P {$timezone="Pacific Standard Time"}
		default {'Invalid Entry timezone will be set to Eastern.'}
	}
	#
	#
	#
	#
	#
	#
	#
	#
	# Disabling UAC
	Echo "Disabling UAC for the duration of this script"
	Echo "It will re-enable later based upon the variables"
	#Set-ItemProperty -Path registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System -Name EnableLUA -Value 0
	Set-ItemProperty -Path REGISTRY::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\System -Name ConsentPromptBehaviorAdmin -Value 0
	Set-ItemProperty -Path REGISTRY::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\System -Name PromptOnSecureDesktop -Value 0

	#PC Name
	echo "Changing PC Name"
	$computerName = Get-WmiObject Win32_ComputerSystem
	$serial = (gwmi win32_bios).SerialNumber
	$new = $CID + "-" + $serial
	$computerName.rename($new)

	#Numlock
	Echo "Enabling Numlock on startup"
	Set-ItemProperty -Path "registry::HKEY_USERS\.DEFAULT\Control Panel\Keyboard" -Name InitialKeyboardIndicators -Value 2

	#Power Settings
	Echo "Setting Power Settings"
	powercfg.exe -x -standby-timeout-ac 0
	powercfg.exe -x -standby-timeout-dc 0
	powercfg.exe -x -hibernate-timeout-ac 0
	powercfg.exe -x -hibernate-timeout-dc 0

	#TimeZone
	Echo "Setting Timezone to EST"
	set-timezone -name $timezone

	#RDP
	Echo "Enabling RDP"
	Set-ItemProperty -Path "registry::HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\Terminal Server" -Name "fDenyTSConnections" -Value 0
	Enable-NetFirewallRule -DisplayGroup "Remote Desktop"

	#This function finds any AppX/AppXProvisioned package and uninstalls it, except for Freshpaint, Windows Calculator, Windows Store, and Windows Photos.
	#Also, to note - This does NOT remove essential system services/software/etc such as .NET framework installations, Cortana, Edge, etc.

	#This is the switch parameter for running this script as a 'silent' script, for use in MDT images or any type of mass deployment without user interaction.

	param (
	  [switch]$Debloat, [switch]$SysPrep
	)

	Function Begin-SysPrep {

		param([switch]$SysPrep)
			Write-Verbose -Message ('Starting Sysprep Fixes')
	 
			# Disable Windows Store Automatic Updates
		   <# Write-Verbose -Message "Adding Registry key to Disable Windows Store Automatic Updates"
			$registryPath = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsStore"
			If (!(Test-Path $registryPath)) {
				Mkdir $registryPath -ErrorAction SilentlyContinue
				New-ItemProperty $registryPath -Name AutoDownload -Value 2 
			}
			Else {
				Set-ItemProperty $registryPath -Name AutoDownload -Value 2 
			}
			#Stop WindowsStore Installer Service and set to Disabled
			Write-Verbose -Message ('Stopping InstallService')
			Stop-Service InstallService 
			#>
	 } 

	#Creates a PSDrive to be able to access the 'HKCR' tree
	New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT
	Function Start-Debloat {
		
		param([switch]$Debloat)

		#Removes AppxPackages
		#Credit to Reddit user /u/GavinEke for a modified version of my whitelist code
		[regex]$WhitelistedApps = 'Microsoft.ScreenSketch|Microsoft.Paint3D|Microsoft.WindowsCalculator|Microsoft.WindowsStore|Microsoft.Windows.Photos|CanonicalGroupLimited.UbuntuonWindows|`
		Microsoft.MicrosoftStickyNotes|Microsoft.MSPaint|Microsoft.WindowsCamera|.NET|Framework|Microsoft.HEIFImageExtension|Microsoft.ScreenSketch|Microsoft.StorePurchaseApp|`
		Microsoft.VP9VideoExtensions|Microsoft.WebMediaExtensions|Microsoft.WebpImageExtension|Microsoft.DesktopAppInstaller'
		Get-AppxPackage -AllUsers | Where-Object {$_.Name -NotMatch $WhitelistedApps} | Remove-AppxPackage -ErrorAction SilentlyContinue
		# Run this again to avoid error on 1803 or having to reboot.
		Get-AppxPackage -AllUsers | Where-Object {$_.Name -NotMatch $WhitelistedApps} | Remove-AppxPackage -ErrorAction SilentlyContinue
		$AppxRemoval = Get-AppxProvisionedPackage -Online | Where-Object {$_.PackageName -NotMatch $WhitelistedApps} 
		ForEach ( $App in $AppxRemoval) {
		
			Remove-AppxProvisionedPackage -Online -PackageName $App.PackageName 
			
			}
	}

	Function Remove-Keys {
			
		Param([switch]$Debloat)    
		
		#These are the registry keys that it will delete.
			
		$Keys = @(
			
			#Remove Background Tasks
			"HKCR:\Extensions\ContractId\Windows.BackgroundTasks\PackageId\46928bounde.EclipseManager_2.2.4.51_neutral__a5h4egax66k6y"
			"HKCR:\Extensions\ContractId\Windows.BackgroundTasks\PackageId\ActiproSoftwareLLC.562882FEEB491_2.6.18.18_neutral__24pqs290vpjk0"
			"HKCR:\Extensions\ContractId\Windows.BackgroundTasks\PackageId\Microsoft.MicrosoftOfficeHub_17.7909.7600.0_x64__8wekyb3d8bbwe"
			"HKCR:\Extensions\ContractId\Windows.BackgroundTasks\PackageId\Microsoft.PPIProjection_10.0.15063.0_neutral_neutral_cw5n1h2txyewy"
			"HKCR:\Extensions\ContractId\Windows.BackgroundTasks\PackageId\Microsoft.XboxGameCallableUI_1000.15063.0.0_neutral_neutral_cw5n1h2txyewy"
			"HKCR:\Extensions\ContractId\Windows.BackgroundTasks\PackageId\Microsoft.XboxGameCallableUI_1000.16299.15.0_neutral_neutral_cw5n1h2txyewy"
			
			#Windows File
			"HKCR:\Extensions\ContractId\Windows.File\PackageId\ActiproSoftwareLLC.562882FEEB491_2.6.18.18_neutral__24pqs290vpjk0"
			
			#Registry keys to delete if they aren't uninstalled by RemoveAppXPackage/RemoveAppXProvisionedPackage
			"HKCR:\Extensions\ContractId\Windows.Launch\PackageId\46928bounde.EclipseManager_2.2.4.51_neutral__a5h4egax66k6y"
			"HKCR:\Extensions\ContractId\Windows.Launch\PackageId\ActiproSoftwareLLC.562882FEEB491_2.6.18.18_neutral__24pqs290vpjk0"
			"HKCR:\Extensions\ContractId\Windows.Launch\PackageId\Microsoft.PPIProjection_10.0.15063.0_neutral_neutral_cw5n1h2txyewy"
			"HKCR:\Extensions\ContractId\Windows.Launch\PackageId\Microsoft.XboxGameCallableUI_1000.15063.0.0_neutral_neutral_cw5n1h2txyewy"
			"HKCR:\Extensions\ContractId\Windows.Launch\PackageId\Microsoft.XboxGameCallableUI_1000.16299.15.0_neutral_neutral_cw5n1h2txyewy"
			
			#Scheduled Tasks to delete
			"HKCR:\Extensions\ContractId\Windows.PreInstalledConfigTask\PackageId\Microsoft.MicrosoftOfficeHub_17.7909.7600.0_x64__8wekyb3d8bbwe"
			
			#Windows Protocol Keys
			"HKCR:\Extensions\ContractId\Windows.Protocol\PackageId\ActiproSoftwareLLC.562882FEEB491_2.6.18.18_neutral__24pqs290vpjk0"
			"HKCR:\Extensions\ContractId\Windows.Protocol\PackageId\Microsoft.PPIProjection_10.0.15063.0_neutral_neutral_cw5n1h2txyewy"
			"HKCR:\Extensions\ContractId\Windows.Protocol\PackageId\Microsoft.XboxGameCallableUI_1000.15063.0.0_neutral_neutral_cw5n1h2txyewy"
			"HKCR:\Extensions\ContractId\Windows.Protocol\PackageId\Microsoft.XboxGameCallableUI_1000.16299.15.0_neutral_neutral_cw5n1h2txyewy"
			   
			#Windows Share Target
			"HKCR:\Extensions\ContractId\Windows.ShareTarget\PackageId\ActiproSoftwareLLC.562882FEEB491_2.6.18.18_neutral__24pqs290vpjk0"
		)
		
		#This writes the output of each key it is removing and also removes the keys listed above.
		ForEach ($Key in $Keys) {
			Write-Output "Removing $Key from registry"
			Remove-Item $Key -Recurse -ErrorAction SilentlyContinue
		}
	}
			
	Function Protect-Privacy {
		
		Param([switch]$Debloat)    

		#Creates a PSDrive to be able to access the 'HKCR' tree
		New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT
			
		#Disables Windows Feedback Experience
		Write-Output "Disabling Windows Feedback Experience program"
		$Advertising = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\AdvertisingInfo'
		If (Test-Path $Advertising) {
			Set-ItemProperty $Advertising -Name Enabled -Value 0 -Verbose
		}
			
		#Stops Cortana from being used as part of your Windows Search Function
		Write-Output "Stopping Cortana from being used as part of your Windows Search Function"
		$Search = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search'
		If (Test-Path $Search) {
			Set-ItemProperty $Search -Name AllowCortana -Value 0 -Verbose
		}
			
		#Stops the Windows Feedback Experience from sending anonymous data
		Write-Output "Stopping the Windows Feedback Experience program"
		$Period1 = 'HKCU:\Software\Microsoft\Siuf'
		$Period2 = 'HKCU:\Software\Microsoft\Siuf\Rules'
		$Period3 = 'HKCU:\Software\Microsoft\Siuf\Rules\PeriodInNanoSeconds'
		If (!(Test-Path $Period3)) { 
			mkdir $Period1 -ErrorAction SilentlyContinue
			mkdir $Period2 -ErrorAction SilentlyContinue
			mkdir $Period3 -ErrorAction SilentlyContinue
			New-ItemProperty $Period3 -Name PeriodInNanoSeconds -Value 0 -Verbose -ErrorAction SilentlyContinue
		}
				   
		Write-Output "Adding Registry key to prevent bloatware apps from returning"
		#Prevents bloatware applications from returning
		$registryPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent"
		If (!(Test-Path $registryPath)) {
			Mkdir $registryPath -ErrorAction SilentlyContinue
			New-ItemProperty $registryPath -Name DisableWindowsConsumerFeatures -Value 1 -Verbose -ErrorAction SilentlyContinue
		}          
		
		Write-Output "Setting Mixed Reality Portal value to 0 so that you can uninstall it in Settings"
		$Holo = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Holographic'    
		If (Test-Path $Holo) {
			Set-ItemProperty $Holo -Name FirstRunSucceeded -Value 0 -Verbose
		}
		
		#Disables live tiles
		Write-Output "Disabling live tiles"
		$Live = 'HKCU:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\PushNotifications'    
		If (!(Test-Path $Live)) {
			mkdir $Live -ErrorAction SilentlyContinue     
			New-ItemProperty $Live -Name NoTileApplicationNotification -Value 1 -Verbose
		}
		
		#Turns off Data Collection via the AllowTelemtry key by changing it to 0
		Write-Output "Turning off Data Collection"
		$DataCollection = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection'    
		If (Test-Path $DataCollection) {
			Set-ItemProperty $DataCollection -Name AllowTelemetry -Value 0 -Verbose
		}
		
		#Disables People icon on Taskbar
		Write-Output "Disabling People icon on Taskbar"
		$People = 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced\People'
		If (Test-Path $People) {
			Set-ItemProperty $People -Name PeopleBand -Value 0 -Verbose
		}

		#Disables suggestions on start menu
		Write-Output "Disabling suggestions on the Start Menu"
		$Suggestions = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager'    
		If (Test-Path $Suggestions) {
			Set-ItemProperty $Suggestions -Name SystemPaneSuggestionsEnabled -Value 0 -Verbose
		}
		
		
		 Write-Output "Removing CloudStore from registry if it exists"
		 $CloudStore = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CloudStore'
		 If (Test-Path $CloudStore) {
		 Stop-Process Explorer.exe -Force
		 Remove-Item $CloudStore -Recurse -Force
		 Start-Process Explorer.exe -Wait
		}

		#Loads the registry keys/values below into the NTUSER.DAT file which prevents the apps from redownloading. Credit to a60wattfish
		reg load HKU\Default_User C:\Users\Default\NTUSER.DAT
		Set-ItemProperty -Path Registry::HKU\Default_User\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager -Name SystemPaneSuggestionsEnabled -Value 0
		Set-ItemProperty -Path Registry::HKU\Default_User\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager -Name PreInstalledAppsEnabled -Value 0
		Set-ItemProperty -Path Registry::HKU\Default_User\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager -Name OemPreInstalledAppsEnabled -Value 0
		reg unload HKU\Default_User
		
		#Disables scheduled tasks that are considered unnecessary 
		Write-Output "Disabling scheduled tasks"
		#Get-ScheduledTask -TaskName XblGameSaveTaskLogon | Disable-ScheduledTask -ErrorAction SilentlyContinue
		Get-ScheduledTask -TaskName XblGameSaveTask | Disable-ScheduledTask -ErrorAction SilentlyContinue
		Get-ScheduledTask -TaskName Consolidator | Disable-ScheduledTask -ErrorAction SilentlyContinue
		Get-ScheduledTask -TaskName UsbCeip | Disable-ScheduledTask -ErrorAction SilentlyContinue
		Get-ScheduledTask -TaskName DmClient | Disable-ScheduledTask -ErrorAction SilentlyContinue
		Get-ScheduledTask -TaskName DmClientOnScenarioDownload | Disable-ScheduledTask -ErrorAction SilentlyContinue
	}

	#This includes fixes by xsisbest
	Function FixWhitelistedApps {
		
		Param([switch]$Debloat)
		
		If(!(Get-AppxPackage -AllUsers | Select Microsoft.Paint3D, Microsoft.MSPaint, Microsoft.WindowsCalculator, Microsoft.WindowsStore, Microsoft.MicrosoftStickyNotes, Microsoft.WindowsSoundRecorder, Microsoft.Windows.Photos)) {
		
		#Credit to abulgatz for the 4 lines of code
		Get-AppxPackage -allusers Microsoft.Paint3D | Foreach {Add-AppxPackage -DisableDevelopmentMode -Register "$($_.InstallLocation)\AppXManifest.xml"}
		Get-AppxPackage -allusers Microsoft.MSPaint | Foreach {Add-AppxPackage -DisableDevelopmentMode -Register "$($_.InstallLocation)\AppXManifest.xml"}
		Get-AppxPackage -allusers Microsoft.WindowsCalculator | Foreach {Add-AppxPackage -DisableDevelopmentMode -Register "$($_.InstallLocation)\AppXManifest.xml"}
		Get-AppxPackage -allusers Microsoft.WindowsStore | Foreach {Add-AppxPackage -DisableDevelopmentMode -Register "$($_.InstallLocation)\AppXManifest.xml"}
		Get-AppxPackage -allusers Microsoft.MicrosoftStickyNotes | Foreach {Add-AppxPackage -DisableDevelopmentMode -Register "$($_.InstallLocation)\AppXManifest.xml"}
		Get-AppxPackage -allusers Microsoft.WindowsSoundRecorder | Foreach {Add-AppxPackage -DisableDevelopmentMode -Register "$($_.InstallLocation)\AppXManifest.xml"}
		Get-AppxPackage -allusers Microsoft.Windows.Photos | Foreach {Add-AppxPackage -DisableDevelopmentMode -Register "$($_.InstallLocation)\AppXManifest.xml"} }
	}

	Function CheckDMWService {

	  Param([switch]$Debloat)
	  
	If (Get-Service -Name dmwappushservice | Where-Object {$_.StartType -eq "Disabled"}) {
		Set-Service -Name dmwappushservice -StartupType Automatic}

	If(Get-Service -Name dmwappushservice | Where-Object {$_.Status -eq "Stopped"}) {
	   Start-Service -Name dmwappushservice} 
	  }

	Function CheckInstallService {
	  Param([switch]$Debloat)
			  If (Get-Service -Name InstallService | Where-Object {$_.Status -eq "Stopped"}) {  
				Start-Service -Name InstallService
				Set-Service -Name InstallService -StartupType Automatic 
				}
			}

	Write-Output "Initiating Sysprep"
	Begin-SysPrep
	Write-Output "Removing bloatware apps."
	Start-Debloat
	Write-Output "Removing leftover bloatware registry keys."
	Remove-Keys
	Write-Output "Checking to see if any Whitelisted Apps were removed, and if so re-adding them."
	FixWhitelistedApps
	Write-Output "Stopping telemetry, disabling unneccessary scheduled tasks, and preventing bloatware from returning."
	Protect-Privacy
	#Write-Output "Stopping Edge from taking over as the default PDF Viewer."
	#Stop-EdgePDF
	CheckDMWService
	CheckInstallService
	Write-Output "Finished all tasks."

	#Install Office 365
	if($InstallOffice -eq "yes"){
	#Uninstall preinstalled office
	echo "Uninstalling all office products"
	c:\BSS\OfficeScrubRemoval.vbs
	#install new office
	echo "Installing office 365"
	c:\BSS\Setup.exe /configure $Office
	copy "c:\programdata\microsoft\windows\start menu\programs\excel*.lnk" c:\users\public\desktop
	copy "c:\programdata\microsoft\windows\start menu\programs\word*.lnk" c:\users\public\desktop
	copy "c:\programdata\microsoft\windows\start menu\programs\outlook*.lnk" c:\users\public\desktop
	$WshShell = New-Object -comObject WScript.Shell
	$Shortcut = $WshShell.CreateShortcut("c:\users\public\Desktop\Internet Explorer.lnk")
	$Shortcut.TargetPath = "C:\Program Files\internet explorer\iexplore.exe"
	$Shortcut.Save()
	}

	#Windows Updates
	Echo "Updating Windows"

	$updateSession = New-Object -ComObject "Microsoft.Update.Session"

	Write-Host "Searching updates..."

	$searcher = $updateSession.CreateupdateSearcher()
	$searchResult = $searcher.Search("IsInstalled=0 and AutoSelectOnWebSites=1")

	if ($searchResult.Updates.Count -eq 0) {
		Write-Host "There are no updates"
		
	} else {
		Write-Host "Found following updates"
		$searchResult.Updates | Format-Table -AutoSize IsDownloaded, MaxDownloadSize, Title

		Write-Host "Downloading updates..."

		$downloader = $updateSession.CreateUpdateDownloader()
		$downloader.Updates = $searchResult.Updates
		$downloadResult = $downloader.Download()

		if ($downloadResult.ResultCode -ne 2) {
			echo "Update Installation Failed"
		}

		Write-Host "Installing updates..."

		$updatesToInstall = New-Object -ComObject "Microsoft.Update.UpdateColl"
		$searchResult.Updates | ? { $_.IsDownloaded } | %{ $updatesToInstall.Add($_) } | Out-Null

		$installer = $updateSession.CreateUpdateInstaller()
		$installer.Updates = $updatesToInstall
		$installResult = $installer.Install()

		if ($installResult.ResultCode -ne 2) {
			echo "Update Installation Failed"
		}

		if ($installResult.RebootRequired) {
			if ($PSCmdlet.ShouldProcess('Restart Computer')) {
				#Restart-Computer
			}
		}
	}

	#Stopping Edge from Creating a desktop icon
	echo "Stopping Edge from Creating a desktop icon"
	reg add HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer /v "DisableEdgeDesktopShortcutCreation" /t REG_DWORD /d "1" /f

	<##Uninstall Dell Command App
	echo "Uninstalling Default Dell Command Application"
	$app = Get-WmiObject -Class Win32_Product | Where-Object { 
		$_.Name -match "Dell Command | Update for Windows 10" 
	}

	$app.Uninstall()
	#wmic product where name='Dell Command | Update for Windows 10' call uninstall

	#Install correct Dell Command
	echo "Installing Dell Command 2.4"
	c:\bss\Dell-Command-Update_DDVDP_WIN_2.4.0_A00.EXE /s
	#wait for install to finish
	Start-Sleep -s 60

	#Run Dell Command Updates
	echo "Running Dell Command"
	& 'C:\Program Files (x86)\Dell\CommandUpdate\dcu-cli.exe' /silent#>

	#UAC
	if($UAC -eq "on"){
		Echo "Enabling UAC"
		#Set-ItemProperty -Path registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System -Name EnableLUA -Value 0
		Set-ItemProperty -Path REGISTRY::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\System -Name ConsentPromptBehaviorAdmin -Value 5
		Set-ItemProperty -Path REGISTRY::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\System -Name PromptOnSecureDesktop -Value 1
	}

	#The End
	Echo "Done"
	Echo "Your PC will reboot in 60 minutes"
	#This isn't working on continuum Set-Content -Path "C:\users\bssadmin\desktop\done.txt" -Value "Done.txt" -Force
	#This isn't working in continuum $wshell = New-Object -ComObject Wscript.Shell
	#This isn't working in continuum $wshell.Popup("PC Prep Completed",0,"Done",0x1)



	Shutdown /r /t 3600s
}
else
{
	write-host "Required files are missing from C:\BSS for installation. Script terminating."
}
